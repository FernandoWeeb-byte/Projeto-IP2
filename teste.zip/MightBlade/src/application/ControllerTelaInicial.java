package application;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.image.ImageView;
import javafx.scene.web.WebView;

public class ControllerTelaInicial {
	
	 	@FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;
	    
	    @FXML
	    private ImageView capa;
	    
	    @FXML
	    private Button criarFicha;

	    @FXML
	    private Button ficha;

	    @FXML
	    private Button regra;

	    
	    @FXML
	    void AcaoDoBotao(ActionEvent event) {
	    	
	    	
	    	
	    		
	    		
	    	
	    	

	    }

	    @FXML
	    void initialize() {
	    	
	    	
	    	
	    }


}
