package ficha;

import java.util.HashMap;

public class Raca {

	private String nome;
	private HashMap<String, Integer> atributos;
	private Habilidade habilidadeAutomatica;
	private HashMap<String, Habilidade> habilidades;
}
