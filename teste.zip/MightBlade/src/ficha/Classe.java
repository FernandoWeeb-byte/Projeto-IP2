package ficha;

import java.util.HashMap;

public class Classe {

	private String nome;
	private HashMap<String, Integer> bonus;
	private Habilidade habilidadeAutomatica;
	private HashMap<String, Habilidade> habilidades;
	
}
