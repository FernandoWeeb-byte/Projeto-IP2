package ficha;

public class Equipamento {

	private String nome;
	private int custo;
	private double peso;
	private String descricao;
	private boolean canalizador;
	
}
