package ficha;

public class Arma extends Equipamento {
	
	private int dano;
	private String tipoDano;
	private String tipoArma;
	private int fN;
	private String distancia;
	private boolean duasMaos;

}
