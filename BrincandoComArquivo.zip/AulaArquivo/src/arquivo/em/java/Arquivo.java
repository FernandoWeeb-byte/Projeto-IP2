package arquivo.em.java;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class Arquivo {
	public static String Read(String Caminho) {
		String conteudo = "";
		
		try {
			FileReader arquivo = new FileReader(Caminho);
			BufferedReader lerArquivo = new BufferedReader(arquivo);
			String linha = "";
			try {
				linha = lerArquivo.readLine();
				while(linha != null) {
					conteudo += linha + "\n";
					linha = lerArquivo.readLine();
				}
				arquivo.close();
			} catch(IOException ex) {
				conteudo = "Erro: N�o foi poss�vel ler o arquivo.";
			}
		} catch(FileNotFoundException ex) {
			conteudo = "Erro: Arquivo n�o encontrado.";
		}
		if(conteudo.contains("Erro")) {
			return "";
		}
		else {
			return conteudo;
		}
	}
	
	public static boolean Write(String caminho, String texto) {
		try {
			FileWriter arquivo = new FileWriter(caminho);
			PrintWriter gravarArquivo = new PrintWriter(arquivo);
			gravarArquivo.println(texto);
			gravarArquivo.close();
			return true;
		} catch(IOException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
}
