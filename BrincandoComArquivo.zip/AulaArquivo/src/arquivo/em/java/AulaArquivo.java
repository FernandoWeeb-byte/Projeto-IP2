package arquivo.em.java;

public class AulaArquivo {

	public static void main(String[] args) {
		String arquivo = "test.txt";
		
		/* ESCRITA
		String texto = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt\n" 
				+ "ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco\n" 
				+ "laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in\n" 
				+ "voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat\n" 
				+ "non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n";
		
		if(Arquivo.Write(arquivo, texto)) {
			System.out.println("Arquivo salvo com sucesso!");
		}
		else {
			System.out.println("Erro ao salvar o arquivo!");
		}
		
		 */
		/* LEITURA
		String texto = Arquivo.Read(arquivo);
		
		if(texto.isEmpty()) {
			System.out.println("Erro ao ler o arquivo!");
		}
		else {
			System.out.println(texto);
		}
		 */
		
		
	}

}
