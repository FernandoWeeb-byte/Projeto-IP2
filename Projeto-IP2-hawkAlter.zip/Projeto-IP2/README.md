qual o nome do grupo mesmo?
might blade

