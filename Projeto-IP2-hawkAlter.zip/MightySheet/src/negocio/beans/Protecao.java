package negocio.beans;

public class Protecao extends Equipamento {
	
	/// Atributos
	private int bloqueio;
	private int esquiva;
	private int fN;
	private boolean escudo;
	private boolean pesada;
	private boolean rigida;
}
