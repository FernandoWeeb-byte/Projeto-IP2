package negocio.beans;

public class Equipamento {
	
	/// Atributos
	private String nome;
	private int custo;
	private double peso;
	private String descricao;
	private boolean canalizador;
}
