package negocio.beans;

public class Arma extends Equipamento {
	
	/// Atributos
	private int dano;
	private String tipoDano;
	private String tipoArma;
	private int fN;
	private String distancia;
	private boolean duasMaos;
}
