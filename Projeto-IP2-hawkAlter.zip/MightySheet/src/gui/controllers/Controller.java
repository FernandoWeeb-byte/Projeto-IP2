package gui.controllers;

import negocio.beans.Personagem;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Controller {
	
	public boolean salvar(String caminho, Personagem personagem) {
		try {
			FileOutputStream fos = new FileOutputStream(new File(caminho));
			ObjectOutputStream oos = new ObjectOutputStream(f);

			// Escreve o objeto no arquivo
			oos.writeObject(personagem);

			oos.close();
			fos.close();
			
			return true;
		} catch(IOException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	public Personagem Carregar(String caminho) {
		try {
			FileInputStream fis = new FileInputStream(new File(caminho));
			ObjectInputStream ois = new ObjectInputStream(fis);

			// L� um objeto do arquivo
			Personagem personagem = (Personagem) ois.readObject();

			ois.close();
			fis.close();
			
			return personagem;
			
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			return null;
		} catch (ClassNotFoundException e) {
			return null;
		}
	}

}
