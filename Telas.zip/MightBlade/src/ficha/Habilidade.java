package ficha;

public class Habilidade {

}
