package ficha;

public class Protecao extends Equipamento {

	private int bloqueio;
	private int esquiva;
	private int fN;
	private boolean escudo;
	private boolean pesada;
	private boolean rigida;
}
